import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getAdminDashboard } from "@/lib/admin.functions";

export const Route = createFileRoute("/AdminXYG/analytics")({ component: AnalyticsPage });

function AnalyticsPage() {
  const fn = useServerFn(getAdminDashboard);
  const [data, setData] = useState<Awaited<ReturnType<typeof fn>> | null>(null);
  useEffect(() => { fn({}).then(setData).catch(() => {}); }, [fn]);
  return (
    <div className="p-6 md:p-8 space-y-4">
      <h1 className="font-display text-2xl font-bold">Analytics</h1>
      {data && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <Stat label="Users" v={data.counts.users} />
          <Stat label="ATMs" v={data.counts.atms} />
          <Stat label="Reports" v={data.counts.reports} />
          <Stat label="Banks" v={data.counts.banks} />
        </div>
      )}
      <p className="text-sm text-muted-foreground">Advanced heatmap & time-series charts coming next.</p>
    </div>
  );
}
function Stat({ label, v }: { label: string; v: number }) {
  return <div className="rounded-2xl border bg-card p-5"><p className="text-2xl font-bold">{v}</p><p className="text-xs text-muted-foreground">{label}</p></div>;
}
