import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { listAdminData, deleteAtm } from "@/lib/admin.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/AdminXYG/atms")({ component: AtmsPage });

type Row = { id: string; name: string; city: string | null; country: string; status: string; created_at: string };

function AtmsPage() {
  const list = useServerFn(listAdminData);
  const del = useServerFn(deleteAtm);
  const [rows, setRows] = useState<Row[]>([]);
  const load = () => list({ data: { table: "atms" } }).then((r) => setRows(r.rows as Row[])).catch(() => {});
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);
  return (
    <div className="p-6 md:p-8 space-y-4">
      <h1 className="font-display text-2xl font-bold">ATMs</h1>
      <div className="rounded-2xl border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted text-xs uppercase text-muted-foreground"><tr><th className="p-3 text-start">Name</th><th className="p-3">City</th><th className="p-3">Country</th><th className="p-3">Status</th><th className="p-3"></th></tr></thead>
          <tbody className="divide-y">
            {rows.map((a) => (
              <tr key={a.id}>
                <td className="p-3">{a.name}</td>
                <td className="p-3 text-center">{a.city}</td>
                <td className="p-3 text-center">{a.country}</td>
                <td className="p-3 text-center">{a.status}</td>
                <td className="p-3 text-center">
                  <button onClick={async () => { if (confirm("Delete?")) { await del({ data: { atmId: a.id } }); toast.success("Deleted"); load(); } }} className="text-xs text-destructive underline">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
